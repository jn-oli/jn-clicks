document.addEventListener('DOMContentLoaded', function () {
    const popup = document.getElementById('popup');
    const closeIcon = document.getElementById('close-icon');

    // Show the popup
    function showPopup() {
        popup.classList.add('show');
    }

    // Close the popup
    function closePopup() {
        popup.classList.remove('show');
    }

    // Close popup when close icon is clicked
    closeIcon.addEventListener('click', closePopup);

    // Show the popup after some delay
    setTimeout(showPopup, 3000); // Adjust the delay (in milliseconds) as needed

    // Message form
    const openButton = document.getElementById('open-button');
    const formPopup = document.getElementById('form-popup');
    const cancelButton = document.getElementById('cancel-button');

    openButton.addEventListener('click', function () {
        formPopup.style.display = 'block';
    });

    cancelButton.addEventListener('click', function () {
        formPopup.style.display = 'none';
    });
});
